#include<stdio.h>

int main()
{
    char name[20];
    printf("enter your name: ");

    //user input taken here
    scanf("%s", name);
    printf("my name is %s.",name);
    
    return 0;
}