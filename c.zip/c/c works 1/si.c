#include<stdio.h>

int main()
{
    float p,n,r,si;
    printf("enter values of p and n ");
    scanf("%f %f",&p,&n100);
    r=9.5;
    si= (p*n*r)/100;

    printf("simple interest = %f ", si); 
    return 0;

}
  