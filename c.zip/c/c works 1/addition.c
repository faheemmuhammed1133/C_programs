#include<stdio.h>
int main()
{
    int a,b,c;
    printf("enter values of a and b");
    scanf("%d %d",&a,&b );

    c=a+b;
    printf("Addition is %d",c);

    return 0;
}